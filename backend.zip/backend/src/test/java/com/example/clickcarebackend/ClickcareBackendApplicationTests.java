package com.example.clickcarebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClickcareBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
