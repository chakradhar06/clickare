import React from 'react'

const DirectMessaging = () => {
  return (
    <div>
      
    </div>
  )
}

export default DirectMessaging
